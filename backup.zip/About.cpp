#include <vcl\vcl.h>

#pragma hdrstop

#include "About.h"

#pragma resource "*.dfm"

TFabout *Fabout;

__fastcall TFabout::TFabout(TComponent *AOwner):TForm(AOwner)
{}

