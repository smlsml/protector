#ifndef PT_objectH
#define PT_objectH

class PT_object
{
   public:

    PT_object(int px , int py , int pv , int pf , TImageList *pointer);
    PT_object(int px, int py , int pv , int pf , int pw, int ph , AnsiString resource_name);
    ~PT_object();

   bool collision(PT_object *other);
   bool collision(int x1 , int y1 , int x2 , int y2);

   bool isAlive();
   bool isEnabled();

   void SetState(bool palive , bool penabled);

   void AddMove(int px , int py);
   void SetMove(int px , int py);

   void AddVel(int pv);
   void SetVel(int pv);

   void AddFrame(int pf);
   void SetFrame(int pf);

   private:

    int w;  // width
    int h;  // height
    int v;  // velocity
    int x;  // x
    int y;  // y
    int f;  // current animation frame

    bool alive;
    bool enabled;

    TimageList *list;
    Graphics::TBitmap *art;
};

#endif
