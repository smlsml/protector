#include <vcl\vcl.h>

#pragma hdrstop

#include "PT_object.h"

PT_object::PT_object(int px, int py , int pv , int pf , int pw, int ph , AnsiString resource_name)
: x(px) , y(py) , v(pv) , f(pf) , w(pw) , h(ph)
{
   art = new Graphics::TBitmap;
   art->LoadFromResourceName((int)HInstance , resource_name);
}

PT_object::PT_object(int px , int py , int pv , int pf , TImageList *pointer)
: x(px) , y(py) , v(pv) , f(pf)
{
   if(pointer) list = pointer;
}

PT_object::~PT_object()
{
   if(art) delete art;
   list->Free();
}

bool PT_object::collision(PT_object *other)
{
   if(!other->isAlive() || !other->IsEnabled() || !alive || !enabled) return false;

   return (y <= other.y + other.h && y + h >= other.y && x <= other.x + other.w && x + w >= other.x);
}

bool PT_object::collision(int x1 , int y1 , int x2 , int y2)
{
   if(!alive || !enabled) return false;

   return (y <= y2 && y + h >= y1 && x <= x2 && x + w >= x1);
}

bool PT_object::isAlive()
{
   return alive;
}

bool PT_object::isEnabled()
{
   return enabled;
}

void PT_object::AddMove(int px , int py)
{
   x += px;
   y += py;
}

void PT_object::SetMove(int px , int py)
{
   x = px;
   y = py;
}

void PT_object::SetState(bool palive , bool penabled)
{
   alive = palive;
   enabled = penabled;
}

void PT_object::AddVel(int pv)
{
   v += pv;
}

void PT_object::SetVel(int pv)
{
   v = pv;
}

void PT_object::AddFrame(int pf)
{
   f += pf;
}

void PT_object::SetFrame(int pf)
{
   f = pf;
}
